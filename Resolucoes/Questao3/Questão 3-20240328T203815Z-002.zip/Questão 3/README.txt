Reference:


https://www.aicrowd.com/challenges/mapping-challenge#datasets